﻿using Microsoft.EntityFrameworkCore;
using Passport_Web.Models.Entities;

namespace Passport_Web.Data
{
    public class ApplicationDbContext : DbContext
    {
        
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
            
        }

        public DbSet<DocType> DocTypes { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Applicant> Applicants { get; set; }
        public DbSet<Order> Order { get; set; }
    }
}
