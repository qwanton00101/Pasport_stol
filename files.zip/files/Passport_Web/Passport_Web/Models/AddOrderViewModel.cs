﻿using Passport_Web.Models.Entities;

namespace Passport_Web.Models
{
    public class AddOrderViewModel
    {
        public Order Order { get; set; }
        public DocType DocType { get; set; }

        public Applicant Applicant { get; set; }

        public User User { get; set; }

        public DateTime RegisterDate { get; set; }

        public DateTime CloseDate { get; set; }

        public string FilePath { get; set; }

        public string Status { get; set; }

        public IEnumerable<DocType> DTypes { get; set; }
        public IEnumerable<Applicant> Apps { get; set; }
    }
}
