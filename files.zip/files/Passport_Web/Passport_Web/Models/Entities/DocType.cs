﻿using System.ComponentModel.DataAnnotations;

namespace Passport_Web.Models.Entities
{
    public class DocType
    {
        public int DocTypeId { get; set; }
        public string Title { get; set; }
        public string Descr { get; set; }        
    }
}