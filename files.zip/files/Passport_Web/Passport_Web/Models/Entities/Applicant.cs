﻿using System.ComponentModel.DataAnnotations;

namespace Passport_Web.Models.Entities
{
    public class Applicant
    {
        public int Id { get; set; }        
        public string LastName { get; set; }       
        public string Name { get; set; }
        public DateTime BirthDate { get; set; }        
        public string Address { get; set; }        
        public string Phone { get; set; }       
    }
}