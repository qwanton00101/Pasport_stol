﻿using System.ComponentModel.DataAnnotations;

namespace Passport_Web.Models.Entities
{
    public class Order
    {
        public int Id { get; set; }
           
        public DocType DocType { get; set; }
              
        public Applicant Applicant { get; set; }
            
        public User User { get; set; }
           
        public DateTime RegisterDate { get; set; }
            
        public DateTime CloseDate { get; set; }
      
        public string FilePath { get; set; }
        
        public string Status { get; set; }       
    }
}