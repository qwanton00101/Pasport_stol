﻿namespace Passport_Web.Models
{
    public class AddDTViewModel
    {
        public string Title { get; set; }
        public string Descr { get; set; }
    }
}
