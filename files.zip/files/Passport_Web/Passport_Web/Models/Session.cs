﻿using Passport_Web.Models.Entities;

namespace Passport_Web.Models
{
    public class Session
    {
        public static User authorized;
    }
}
