﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Passport_Web.Data;
using Passport_Web.Models;
using Passport_Web.Models.Entities;

namespace Passport_Web.Controllers
{
    public class DTController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public DTController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddDTViewModel addDTViewModel)
        {
            var dt = new DocType
            {
                Descr = addDTViewModel.Descr,
                Title = addDTViewModel.Title
            };
            await dbContext.DocTypes.AddAsync(dt);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("DTList", "DT");
        }

        [HttpGet]
        public async Task<IActionResult> DTList()
        {
            var dts = await dbContext.DocTypes.ToListAsync();
            return View(dts);
        }

        [HttpGet]
        public async Task<IActionResult> EditDT(int id)
        {
           var dt = await dbContext.DocTypes.Where(d => d.DocTypeId == id).FirstOrDefaultAsync();
           return View(dt);
        }

        [HttpPost]
        public async Task<IActionResult> EditDT(DocType dt)
        {
            var editing_dt = await dbContext.DocTypes.FindAsync(dt.DocTypeId);            
            if (editing_dt is not null) 
            {
                editing_dt.Title = dt.Title;
                editing_dt.Descr = dt.Descr;

                await dbContext.SaveChangesAsync();
            }

            return RedirectToAction("DTList", "DT");
        }
        
        public async Task<IActionResult> DeleteDT(int id)
        {
            var del_dt = await dbContext.DocTypes.FindAsync(id);
            if (del_dt is not null)
            {
                dbContext.DocTypes.Remove(del_dt);  
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("DTList", "DT");
        }
    }
}