﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Passport_Web.Data;
using Passport_Web.Models;
using Passport_Web.Models.Entities;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Passport_Web.Controllers
{
    public class UsersController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public UsersController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(User user)
        {
            var usr = await dbContext.Users.Where(u => u.Username.Equals(user.Username) & u.Password.Equals(user.Password)).FirstOrDefaultAsync();
            if (usr != null)
            {
                HttpContext.Session.SetString("user_id", usr.Id.ToString());
                Session.authorized = usr;
                
                if (usr.Role == "user") 
                {
                    return RedirectToAction("DTList", "DT");
                }
                else if (usr.Role == "admin")
                {
                    return RedirectToAction("Dashboard", "Users");
                }
                else
                {
                    return RedirectToAction("Login", "Users");
                }
            }
            else
            {
                return RedirectToAction("Users", "Login");
            }
        }

        public IActionResult Dashboard()
        {
            var users = dbContext.Users.ToList();
            return View(users);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddUserViewModel addUserViewModel)
        {
            var u = new User
            {
               Role = addUserViewModel.Role,
               Username = addUserViewModel.Username,
               Password = addUserViewModel.Password
            };
            await dbContext.Users.AddAsync(u);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("Dashboard", "Users");
        }

        [HttpGet]
        public async Task<IActionResult> EditUser(int id)
        {
            var user = await dbContext.Users.Where(u => u.Id == id).FirstOrDefaultAsync();
            return View(user);
        }

        [HttpPost]
        public async Task<IActionResult> EditUser(User usr)
        {
            var editing_u = await dbContext.Users.FindAsync(usr.Id);
            if (editing_u is not null)
            {
                editing_u.Username = usr.Username;
                editing_u.Password = usr.Password;
                editing_u.Role = usr.Role; 
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("Dashboard", "Users");
        }

        public async Task<IActionResult> DeleteUser(int id)
        {
            var del_u = await dbContext.Users.FindAsync(id);
            if (del_u is not null)
            {
                dbContext.Users.Remove(del_u);
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("Dashboard", "Users");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Remove("user_id");
            Session.authorized = null;
            return RedirectToAction("Login", "Users");
        }

    }
}