﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Passport_Web.Data;
using Passport_Web.Models.Entities;
using Passport_Web.Models;

namespace Passport_Web.Controllers
{
    public class OrderController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public OrderController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]
        public async Task<IActionResult> OrdList()
        {
            var ords = await dbContext.Order.Include("DocType").Include("Applicant").Include("User").ToListAsync();
            return View(ords);
        }      

        [HttpGet]
        public IActionResult Add()
        {
            var dts = dbContext.DocTypes.ToList();
            var apps = dbContext.Applicants.ToList();
            AddOrderViewModel addOrderViewModel = new AddOrderViewModel();
            addOrderViewModel.DTypes = dts;
            addOrderViewModel.Apps = apps;
            return View(addOrderViewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddOrderViewModel addOrderViewModel)
        {
            var app = await dbContext.Applicants.FindAsync(addOrderViewModel.Applicant.Id);
            var dt = await dbContext.DocTypes.FindAsync(addOrderViewModel.DocType.DocTypeId);
            var user = await dbContext.Users.FindAsync(Session.authorized.Id);
            var ord = new Order
            {
               Applicant = app,
               CloseDate = addOrderViewModel.CloseDate,
               DocType = dt,
               FilePath = "",
               RegisterDate = addOrderViewModel.RegisterDate,   
               Status = addOrderViewModel.Status,
               User = user
            };
            await dbContext.Order.AddAsync(ord);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("OrdList", "Order");
        }

        [HttpGet]
        public async Task<IActionResult> EditApp(int id)
        {
            var app = await dbContext.Applicants.Where(a => a.Id == id).FirstOrDefaultAsync();
            return View(app);
        }

        [HttpPost]
        public async Task<IActionResult> EditApp(Applicant app)
        {
            var editing_app = await dbContext.Applicants.FindAsync(app.Id);
            if (editing_app is not null)
            {
                editing_app.LastName = app.LastName;
                editing_app.Name = app.Name;
                editing_app.BirthDate = app.BirthDate;
                editing_app.Address = app.Address;
                editing_app.Phone = app.Phone;

                await dbContext.SaveChangesAsync();
            }

            return RedirectToAction("ApList", "Applicant");
        }

        public async Task<IActionResult> DeleteApp(int id)
        {
            var del_app = await dbContext.Applicants.FindAsync(id);
            if (del_app is not null)
            {
                dbContext.Applicants.Remove(del_app);
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("ApList", "Applicant");
        }
    }
}
