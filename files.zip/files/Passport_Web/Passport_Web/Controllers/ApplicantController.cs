﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Passport_Web.Data;
using Passport_Web.Models.Entities;
using Passport_Web.Models;

namespace Passport_Web.Controllers
{
    public class ApplicantController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public ApplicantController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public async Task<IActionResult> ApList()
        {
            var apps = await dbContext.Applicants.ToListAsync();
            return View(apps);
        }        

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddAppViewModel addAppViewModel)
        {
            var app = new Applicant
            {
                Address = addAppViewModel.Address,
                BirthDate = addAppViewModel.BirthDate,
                LastName = addAppViewModel.LastName,
                Name = addAppViewModel.Name,    
                Phone = addAppViewModel.Phone
            };
            await dbContext.Applicants.AddAsync(app);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("ApList", "Applicant");
        }

        [HttpGet]
        public async Task<IActionResult> EditApp(int id)
        {
            var app = await dbContext.Applicants.Where(a => a.Id == id).FirstOrDefaultAsync();
            return View(app);
        }

        [HttpPost]
        public async Task<IActionResult> EditApp(Applicant app)
        {
            var editing_app = await dbContext.Applicants.FindAsync(app.Id);
            if (editing_app is not null)
            {
                editing_app.LastName = app.LastName;
                editing_app.Name = app.Name;
                editing_app.BirthDate = app.BirthDate;
                editing_app.Address = app.Address;
                editing_app.Phone = app.Phone;

                await dbContext.SaveChangesAsync();
            }

            return RedirectToAction("ApList", "Applicant");
        }

        public async Task<IActionResult> DeleteApp(int id)
        {
            var del_app = await dbContext.Applicants.FindAsync(id);
            if (del_app is not null)
            {
                dbContext.Applicants.Remove(del_app);
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("ApList", "Applicant");
        }

    }
}
