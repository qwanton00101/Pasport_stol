﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Passport_Web.Migrations
{
    /// <inheritdoc />
    public partial class C : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_DocTypes",
                table: "DocTypes");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "DocTypes");

            migrationBuilder.AddColumn<int>(
                name: "DocTypeId",
                table: "DocTypes",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_DocTypes",
                table: "DocTypes",
                column: "DocTypeId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_DocTypes",
                table: "DocTypes");

            migrationBuilder.DropColumn(
                name: "DocTypeId",
                table: "DocTypes");

            migrationBuilder.AddColumn<Guid>(
                name: "Id",
                table: "DocTypes",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddPrimaryKey(
                name: "PK_DocTypes",
                table: "DocTypes",
                column: "Id");
        }
    }
}
